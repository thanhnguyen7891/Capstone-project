const userUrl='http://localhost:8080/user';
export {userUrl}

const questionnUrl='http://localhost:8080/question';
export {questionnUrl}