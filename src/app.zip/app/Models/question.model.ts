export class QuestionModel{
    title: string='';
    topic: string='';
    description_question: string='';
    datetime: string='';
    id: number=0;
    status: string='';
    image_src: string='';
}