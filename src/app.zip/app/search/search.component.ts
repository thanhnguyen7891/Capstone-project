import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { questionnUrl } from '../Models/baseUrl';
import { QuestionModel } from '../Models/question.model';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  constructor(
    private router : Router,
    private service: ApiService,
    private route : ActivatedRoute
  ){}

  ngOnInit(): void {
      
  }
  id! : number;
  question = new QuestionModel();
  data!: any;
  getQuestionById(id: number){
    this.service.get(questionnUrl + '/getquestionbyid'+id)
    .subscribe(res =>{
      this.data = res;
      this.question = this.data;
      console.log(this.question)
    })
  }
  getQuestionByTopic(topic: any){
    this.service.get(questionnUrl+ '/getQuestionbytopic'+topic)
    .subscribe(res =>{
      this.data = res;
      this.question = this.data;
      console.log(this.question)
    })
  }
}
