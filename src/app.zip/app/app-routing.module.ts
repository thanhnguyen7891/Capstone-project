import { NgModule, Query } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './user/user.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { QuestionComponent } from './question/question.component';
import { PendingQuestionComponent } from './pending-question/pending-question.component';
import { PendingAnswerComponent } from './pending-answer/pending-answer.component';
import { CreateQuestionComponent } from './create-question/create-question.component';
import { SearchComponent} from './search/search.component';

const routes: Routes = [
  { path: '', redirectTo: 'user', pathMatch:'full'},
  { path: 'login', component: LoginComponent},
  { path: 'signup', component: SignupComponent},
  { path: 'user', component: DashboardComponent},
  { path: 'updateUser/:id', component: UpdateUserComponent},
  { path: 'question', component: QuestionComponent},
  { path: 'create-question', component: CreateQuestionComponent},
  { path: 'pending-question', component: PendingQuestionComponent},
  { path: 'pedning-answer', component: PendingAnswerComponent},
  { path: 'search', component: SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
