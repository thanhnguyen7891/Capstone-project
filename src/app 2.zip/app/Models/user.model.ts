export class UserModel{
    id?: number;
    name:string='';
    username: string='';
    password: string='';
    email: string='';
    userType: string='';
}