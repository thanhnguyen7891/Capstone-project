export class QuestionModel{
    title: string='';
    topic: string='';
    description_question: string='';
    datetime: string='';
    id?: number;
    status: string='';
    image_src: string='';
    created_by: string='';
}