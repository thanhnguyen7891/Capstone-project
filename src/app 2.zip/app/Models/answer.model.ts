export class AnswerModel{
    id: number=0;
    image_src: string='';
    description_answer: string='';
    status: string='';
    created_by: string='';
}