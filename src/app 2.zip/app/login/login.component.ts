import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { userUrl } from '../Models/baseUrl';
import { UserModel } from '../Models/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private service: ApiService,
    private router: Router
  ){}
  
  ngOnInit(): void {
      this.userLogin();
  }
  user = new UserModel();
  userLogin(){
    this.service.post(userUrl+ '/getLogin',this.user)
    .subscribe(res =>{
      console.log(res)
    })
  }
}
