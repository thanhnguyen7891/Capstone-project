import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { answerUrl } from '../Models/baseUrl';

@Component({
  selector: 'app-pending-answer',
  templateUrl: './pending-answer.component.html',
  styleUrls: ['./pending-answer.component.css']
})
export class PendingAnswerComponent implements OnInit {
  currentDate = new Date();
  constructor(
    private route: ActivatedRoute,
    private service: ApiService,
    private router: Router
  ){}

  ngOnInit(): void {
      this.pendingAnswer();
      //this.declined(this.answers.id);
      this.approved();
  }
  
  answers: any;
  pendingAnswer(){
    this.service.get(answerUrl+ '/getallanswers')
    .subscribe(res =>{
      this.answers = res;
      console.log(this.answers);
    })
  }

  approved(){
    this.service.put(answerUrl+ '/updateanswer',this.answers)
    .subscribe(res =>{
      this.router.navigate(['answer']);
      console.log(res)
    })
  }
  declined(id: number){
    this.service.delete(answerUrl+'deleteanswerbyid'+id)
    .subscribe(res =>{
      this.pendingAnswer();
      console.log(res);
    })

  }
}
