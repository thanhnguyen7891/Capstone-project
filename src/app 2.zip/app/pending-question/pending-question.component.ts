import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { questionnUrl } from '../Models/baseUrl';
import { QuestionModel } from '../Models/question.model';

@Component({
  selector: 'app-pending-question',
  templateUrl: './pending-question.component.html',
  styleUrls: ['./pending-question.component.css']
})
export class PendingQuestionComponent implements OnInit {
  currentDate = new Date();
  constructor(
    private route: ActivatedRoute,
    private service: ApiService,
    private router: Router
  ){}

  ngOnInit(): void {
      this.pendingQuestion();
      this.declined(this.questions.id);
      this.approved();
  }
  
  questions: any;
  pendingQuestion(){
    this.service.get(questionnUrl+ '/getallquestion')
    .subscribe(res =>{
      this.questions = res;
      console.log(this.questions);
    })
  }
  approved(){
    this.service.put(questionnUrl+ '/updatequestion', this.questions)
    .subscribe(res =>{
      this.router.navigate(['question']);
    })
  }

  declined(id: number){
    this.service.delete(questionnUrl+'deleteanswerbyid'+id)
    .subscribe(res =>{
      this.pendingQuestion();
      console.log(res);
    })

  }
}
